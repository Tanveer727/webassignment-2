﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace calc.Controllers
{
    public class FindDiviController : ApiController
    {
        [HttpGet]
        public string GetNumbers(string firstnumber, string secondnumber)
        {
           
            if(Convert.ToInt16(secondnumber)==0)
            {
                string msg = "this is not possible";
                return msg;
            }
            else
            {
                int c = Convert.ToInt16(firstnumber) / Convert.ToInt16(secondnumber);
                return (c.ToString());

            }
           
        }
    }
}

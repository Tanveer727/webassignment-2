﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace calc.Controllers
{
    public class FindSubController : ApiController
    {
        [HttpGet]
        public string GetNumbers(string firstnumber, string secondnumber)
        {

            int c = Convert.ToInt16(firstnumber) - Convert.ToInt16(secondnumber);
            return (c.ToString());
        }

    }
}
